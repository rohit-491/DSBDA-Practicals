# Improving-Social-Network-ads
Prediction system to predict which user is going to buy a product displayed on a social media advertisement using random forest classification.
